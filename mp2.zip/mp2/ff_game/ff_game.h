#ifndef FF_GAME_H
#define FF_GAME_H
#include <iostream>

class ff_game
{


}

#endif
