#ifndef WORD_SUDOKU_H
#define WORD_SUDOKU_H
#include <string>
#include <fstream>
#include <iostream>
#include <vector>

class ws_game
{
public:
	void make(std::string wordfile, std::string gridfile);
	void solve();
private:

	struct ws_grid
	{
		char grid[9][9];
		std::vector<std::string> words;
	};

	std::vector<std::string> words;
	char start_grid[9][9];
	void readFromWordFile(std::string filename);
	void readFromGridFile(char grid[9][9], std::string filename);
	bool checkSubGrid(char a, int subGrid);
	bool addWord(std::vector<char> word, int o, int r, int c);
	void solve_helper(char grid[9][9]);
	void printGrid(char grid[9][9]);
	void clear();
};

#endif
