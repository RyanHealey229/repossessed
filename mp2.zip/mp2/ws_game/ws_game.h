#ifndef WORD_SUDOKU_H
#define WORD_SUDOKU_H
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>

class ws_game
{
public:
	ws_game(std::string wordfile);
	ws_game(std::string wordfile, std::string gridfile);
	void play();
	void solve();
private:

	struct ws_grid
	{
		char grid[9][9];
		std::vector<std::string> words;
	};

	std::vector<std::string> words;
	char start_grid[9][9];
	void readFromWordFile(std::string filename);
	void readFromGridFile(std::string filename);
	bool addWord(char grid[9][9], std::vector<std::string> words, std::string word, int o, int r, int c);
	bool play_helper(char grid[9][9], std::vector<std::string> wordsLeft);
	void solve_helper(char grid[9][9], std::vector<std::string> wordsLeft);
	void printGrid(char grid[9][9]);
	void clear();
};

#endif
