#include "ws_game.h"

int main()
{
	ws_game game;
	game.make("bank1.txt", "grid1.txt");
	return 0;
};
