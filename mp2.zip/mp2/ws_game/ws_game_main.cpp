#include "ws_game.h"

int main()
{
	ws_game game("bank2.txt");
	game.play();
	return 0;
};
