#include "ws_game.h"

//---------- public

ws_game::ws_game(std::string wordfile)
{
	readFromWordFile(wordfile);
	for (size_t i = 0; i < 9; i++) for (size_t j = 0; j < 9; j++) start_grid[i][j] = '_';
}

ws_game::ws_game(std::string wordfile, std::string gridfile)
{
	readFromWordFile(wordfile);
	readFromGridFile(gridfile);
}

void ws_game::play()
{
	printGrid(start_grid);
	std::cout << "Words:" << std::endl;
	for (size_t i = 0; i < words.size(); i++) std::cout << words[i] << std::endl;
	play_helper(start_grid, words);
}

void ws_game::solve()
{
}

//---------- private

void ws_game::readFromWordFile(std::string filename)
{
	std::ifstream wordbank(filename);
	for (std::string line; getline(wordbank, line);) words.push_back(line);
}

void ws_game::readFromGridFile(std::string filename)
{
	std::ifstream hintbank(filename);
	int i = 0;
	for (std::string line; getline(hintbank, line); i++)
		for (size_t j = 0; j < line.length(); j++)
			start_grid[i][j] = line[j];
}

bool ws_game::addWord(char grid[9][9], std::vector<std::string> wordsLeft, std::string word, int o, int r, int c)
{
	//--------- CANNOT FIND WORD IN VECTOR
	//if (!(std::binary_search(wordsLeft.begin(), wordsLeft.end(), word)))// return false;
	//{ std::cout << "This word is not in the wordbank" << std::endl; return false; }
	bool inWordBank = true;
	for (size_t i = 0; i < wordsLeft.size(); i++) 
	{
		std::cout << wordsLeft[i] << std:: endl;
		if (word.compare(wordsLeft[i]) == 0) inWordBank = true;
	}
	if (std::find(wordsLeft.begin(), wordsLeft.end(), word) != wordsLeft.end()) inWordBank = true;
	if (!inWordBank) { std::cout << word << " is not in the wordbank" << std::endl; return false; }



	if (o < 0 || o > 1 || r < 0 || r > 8 || c < 0 || c > 8)// return false;
	{ std::cout << "Invalid index" << std::endl; return false; }
	char test_grid[9][9];
	for (int i = 0; i <  9; i++) for (int j = 0; j < 9; j++) test_grid[i][j] = grid[i][j];
	int pos_x, pos_y, sub_x, sub_y;
	int dx = 0;
	int dy = 0;
	if (o == 0) dx = 1;
	if (o == 1) dy = 1;
	for (size_t i = 0; i < word.length(); i++)
	{
		pos_x = c + dx*i;
		pos_y = r + dy*i;
		if (test_grid[pos_x][pos_y] != '_')// return false;
		{ std::cout << "This word does not fit here" << std::endl; return false; }
		sub_x = floor(pos_x/3)*3;
		sub_y = floor(pos_y/3)*3;
		for (int a = 0; a < 3; a++)
			for (int b = 0; b < 3; b++)
				if (test_grid[sub_x+a][sub_y+b] == word[i])
				{ std::cout << "The letter " << word[i] << " is already in this subgrid" << std::endl; return false;}
					//return false;
		test_grid[pos_x][pos_y] = word[i];
		// Also test letter in column, row
	}
	for (int i = 0; i <  9; i++) for (int j = 0; j < 9; j++) grid[i][j] = test_grid[i][j];
	return true;
}

bool ws_game::play_helper(char grid[9][9], std::vector<std::string> wordsLeft)
{
	std::cout << std::endl;
	if (wordsLeft.empty()) {std::cout << "Solved!" << std::endl; return true;}

	char grid2[9][9];
	for (int i = 0; i <  9; i++) for (int j = 0; j < 9; j++) grid2[i][j] = grid[i][j];

	std::string word;
	int o, r, c;
	bool valid;
	do {
		printGrid(grid);
		valid = false;
		while (!valid)
		{
			std::cout << "Add a word (word | orientation | top row | left column)" << std::endl;
			std::cout << "Or get words list (getWord 0 0 0)" << std::endl;
			std::cout << "Or undo last move (undo 0 0 0): " << std::flush;
			std::cin >> word >> o >> r >> c;
			if (word.compare("undo") == 0) return false;
			else if (word.compare("getWord") == 0)
			{
				std::cout << "Words:" << std::endl;
				for (size_t i = 0; i < wordsLeft.size(); i++) 
					std::cout << wordsLeft[i] << std::endl;
			}
			else if (!(addWord(grid2, wordsLeft, word, o, r, c))) std::cout << "invalid move: try again" << std::endl;
			else valid = true;
		}
		//------- ONLY ERASES LAST WORD
		wordsLeft.erase(std::find(wordsLeft.begin(), wordsLeft.end(), word));
	} while (!play_helper(grid2, wordsLeft));
	for (int i = 0; i <  9; i++) for (int j = 0; j < 9; j++) grid[i][j] = grid2[i][j];
	return true;
}

void ws_game::solve_helper(char grid[9][9], std::vector<std::string> wordsLeft)
{
}

void ws_game::printGrid(char grid[9][9])
{
	for (int i = 0; i < 9; i++)
	{
		std::cout << grid[i][0] << ' ' << grid[i][1] << ' ' << grid[i][2] << '|';
		std::cout << grid[i][3] << ' ' << grid[i][4] << ' ' << grid[i][5] << '|';
		std::cout << grid[i][6] << ' ' << grid[i][7] << ' ' << grid[i][8] << std::endl;
		if (i == 2 || i==5) std::cout << "-----+-----+-----" << std::endl;
	}
}

void ws_game::clear()
{ 
	words.clear(); 
	for (int i = 0; i < 9; i++) for (int j = 0; j < 9; j++) start_grid[i][j] = '_';
}





