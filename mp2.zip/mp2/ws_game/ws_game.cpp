#include "ws_game.h"

//---------- public

void ws_game::make(std::string wordfile, std::string gridfile)
{
	clear();
	std::ifstream wordbank(wordfile);
	for (std::string line; getline(wordbank, line);) words.push_back(line);
	std::ifstream hintbank(gridfile);
	int i = 0;
	for (std::string line; getline(hintbank, line); i++)
		for (size_t j = 0; j < line.length(); j++)
			start_grid[i][j] = line[j];
	std::cout << "Created Word Sudoku Game" << std::endl;
	std::cout << "Words:" << std::endl;
	for (size_t i = 0; i < words.size(); i++) std::cout << words[i] << std::endl;
	printGrid(start_grid);
}

void ws_game::solve()
{
}

//---------- private

void ws_game::readFromWordFile(std::string filename)
{
}

void ws_game::readFromGridFile(char grid[9][9], std::string filename)
{
}

bool ws_game::checkSubGrid(char a, int subGrid)
{
	return false;
}

bool ws_game::addWord(std::vector<char> word, int o, int r, int c)
{
	return false;
}

void ws_game::solve_helper(char grid[9][9])
{
}

void ws_game::printGrid(char grid[9][9])
{
	for (int i = 0; i < 9; i++)
	{
		std::cout << grid[i][0] << ' ' << grid[i][1] << ' ' << grid[i][2] << '|';
		std::cout << grid[i][3] << ' ' << grid[i][4] << ' ' << grid[i][5] << '|';
		std::cout << grid[i][6] << ' ' << grid[i][7] << ' ' << grid[i][8] << std::endl;
		if (i == 2 || i==5) std::cout << "-----+-----+-----" << std::endl;
	}
}

void ws_game::clear()
{ 
	words.clear(); 
	for (int i = 0; i < 9; i++) for (int j = 0; j < 9; j++) start_grid[i][j] = '_';
}
