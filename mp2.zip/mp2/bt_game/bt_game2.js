//===================================================================
//  BT_Game Implementation                                         //
//===================================================================
// Needs adjustments to manage local objects			   //
//===================================================================


//===================================================================
// Define Classes

function Piece(rr, cc, pp) {
	this.row = rr;
	this.col = cc;
	this.player = pp;
}

function Board(board) {
	var p;
	var piece;
	this.grid = [];
	this.pieces = [[],[],[]];
	if (!board) {
		this.score = 0;
		for (var row = 0; row < 8; row++) {
			this.grid.push([]);
			if (row < 2) p = 2;
			else if (row > 5) p = 1;
			else p = 0;
			for (var col = 0; col < 8; col++) {
				piece = new Piece(col,row,p)
				this.grid[row].push(piece);
				this.pieces[p].push(piece);
				console.log("Added a piece");
			}
		}
	} else {
		this.score = board.score;
		for (var row = 0; row < 8; row++) {
			this.grid.push([]);
			for (var col = 0; col < 8; col++) {
				p = board.grid[row][col].player;
				piece = new Piece(row, col, p);
				this.grid[row].push(piece);
				this.pieces[p].push(piece);
			}
		}
	}
}

function BT_Game(p1str, p2str) {
	// Player strings: 'usr1', 'mmD1', 'mmD2', 'abD1', 'abD2', 'abO1', 'abO2'
	this.p1 = p1str;
	this.p2 = p2str;
	this.expanded = 0;
}


//===================================================================
// Initialize Board

BT_Game.prototype.start = function() {
	this.play(new Board(null), this.p1, this.p2);
}

//===================================================================
// Play

BT_Game.prototype.play = function(board, p1, p2) {
	var board_copy = new Board(board);
	var moveChoice = (0, 0, 0);

	// Show board
	this.printGrid(board_copy.grid);
	this.updateHTML(board_copy.grid);

	// Player 1 move
	moveChoice = this.getMove(board_copy, p1, p2, true);
	this.move(board_copy, moveChoice[0], moveChoice[1]);

	// Check win
	if (this.checkWin(board_copy) == 1) {console.log("Player 1 wins"); return;}

	// Show board
	this.printGrid(board_copy.grid);
	this.updateHTML(board_copy.grid);

	// Player 2 move
	moveChoice = this.getMove(board_copy, p2, p1, false);
	this.move(board_copy, moveChoice[0], moveChoice[1]);

	// Check win
	if (this.checkWin(board_copy) == 2) {console.log("Player 2 wins"); return;}

	// Next move
	play(board_copy, p1, p2);
}

//===================================================================
// Show board

BT_Game.prototype.printGrid = function(grid) {
	var logtext = "";
	logtext += "  | 0 1 2 3 4 5 6 7\n";
	logtext += "--+----------------\n";
	for (var i = 0; i < 8; i++) {
		logtext += i;
		logtext += "|";
		for (var j = 0; j < 8; j++) {
			if      (grid[i][j].player == 1) logtext += " X";
			else if (grid[i][j].player == 2) logtext += " O";
			else                             logtext += " _";
		}
		logtext += "\n";
	}
	console.log(logtext);
}

BT_Game.prototype.updateHTML = function(grid) {
	var htmltext = "";
	for (var i = 0; i < 8; i+=2) {
		htmltext += "<div class='row'>";
		for (var j = 0; j < 7; j+=2) {
			htmltext += "<div class='space space_b'>";
			if (grid[i][j].player == 1)
				htmltext += "<div class='piece p1'></div>";
			if (grid[i][j].player == 2)
				htmltext += "<div class='piece p2'></div>";
			htmltext += "</div><div class='space space_w'>";
			if (grid[i][j+1].player == 1)
				htmltext += "<div class='piece p1'></div>";
			if (grid[i][j+1].player == 2)
				htmltext += "<div class='piece p2'></div>";
			htmltext += "</div>";
		}
		htmltext += "</div><div class='row'>";
		for (var j = 0; j < 7; j+=2) {
			htmltext += "<div class='space space_w'>";
			if (grid[i+1][j].player == 1)
				htmltext += "<div class='piece p1'></div>";
			if (grid[i+1][j].player == 2)
				htmltext += "<div class='piece p2'></div>";
			htmltext += "</div><div class='space space_b'>";
			if (grid[i+1][j+1].player == 1)
				htmltext += "<div class='piece p1'></div>";
			if (grid[i+1][j+1].player == 2)
				htmltext += "<div class='piece p2'></div>";
			htmltext += "</div>";
		}
		htmltext += "</div>";
	}
	$('#board').html(htmltext);
}

//===================================================================
// Search by strategy

BT_Game.prototype.getMove = function(board, player, opponent, isP1) {
	console.log("Getting Move");
	var eval = 'eval' + player[2] + player[3];
	var eval2 = 'eval' + opponent[2] + '1';

	// User
	if (player[0] == 'u') return this.userMove(board, isP1);

	// Minimax
	else if (player[0] == 'm') return minimax(board, 3, isP1, eval); 

	// Alpha-Beta
	else if (player[0] == 'a') return alphabeta(board, 3, isP1, eval);

	// Default
	else return (0, 0, 0);
}

BT_Game.prototype.userMove = function(board, isP1) {
	console.log("Getting User Move");
	var prompt_txt, invars, row, col, dx, pc;
	var p = (isP1 ? 1 : 2);
	var valid = false;
	while (!valid) {
		prompt_txt = "Player " + p + " move (row col dx): ";
		input = prompt(prompt_txt);
		if (input) {
			invars = input.split(' ');
			row = parseInt(invars[0]);
			col = parseInt(invars[1]);
			dx = parseInt(invars[2]);
			pc = board.grid[row][col];
			console.log(pc.row, pc.col, dx);
			valid = (pc.player == p && this.validMove(board, pc, dx));
			if (!valid) console.log("invalid move: try again");
		}
	}
	console.log(pc, dx);
	return (pc, dx, 0);
}

BT_Game.prototype.minimax = function(board, depth, isMax, eval) {
	console.log("Getting Minimax Move");
	if (depth == 0 || checkWin(board)) return (0, 0, eval(board));
	var best, m2;
	var board_copy = new Board(board);
	if (isMax) {
		best = (0, 0, -Infinity);
		for (var m in this.getMoves(board)) {
			if (this.move(board_copy, m[0], m[1])) {
				m2 = minimax(board_copy, depth-1, false, eval);
				m[2] = m2[2];
				if (m[2] > best[2]) best = m;
			}
		}
	} else {
		best = (0, 0, Infinity);
		for (var m in this.getMoves(board)) {
			if (this.move(board_copy, m[0], m[1])) {
				m2 = minimax(board_copy, depth-1, true, eval);
				m[2] = m2[2];
				if (m[2] < best[2]) best = m;
			}
		}
	}
	return best;
}

BT_Game.prototype.alphabeta = function(board, depth, isMax, eval) {
	console.log("Getting Alpha-Beta Move");
}

//===================================================================
// Get moves from a board

BT_Game.prototype.getMoves = function(board, isP1) {
	var p = isP1 ? 1 : 2;
	var moves = [];
	for (var pc in board.pieces[p])
		for (var i = -1; i < 2; i++)
			moves.push((pc, i, 0));
	return moves;
}

//===================================================================
// Evaluate board

BT_Game.prototype.evalD1 = function(board, p) {
	var pCount = 0;
	for (var i = 0; i < 8; i++)
		for (var j = 0; j < 8; j++) 
			if (board.grid[i][j].player == 3-p)
				pCount++;
	return 2*(30-pCount) + Math.random();
}

BT_Game.prototype.evalO1 = function(board, p) {
	var pCount = 0;
	for (var i = 0; i < 8; i++)
		for (var j = 0; j < 8; j++) 
			if (board.grid[i][j].player == p)
				pCount++;
	return 2*(pCount) + Math.random();
}

BT_Game.prototype.evalD2 = function(board, p) {
	return evalD1(board, p);
}

BT_Game.prototype.evalO2 = function(board, p) {
	return evalO1(board, p);
}

//===================================================================
// Check validity

BT_Game.prototype.validMove = function(board, pc, dx) {
	if (dx != -1 && dx != 0 && dx != 1) {console.log("Invalid dx"); return false;}
	if (pc.col+dx < 0 || pc.col+dx > 7) {console.log("Invalid destination"); return false;}

	var dy;
	if 	(pc.player == 1) dy = -1;
	else if (pc.player == 2) dy =  1;
	else return false;

	var dest = board.grid[pc.row+dy][pc.col+dx];
	if (dest.player == pc.player || (dest.player != 0 && dx == 0)) {console.log("Invalid capture"); return false;}

	return true;
}

//===================================================================
// Make the move

BT_Game.prototype.move = function(board, pc, dx) {
	console.log (pc, dx);
	if (dx != -1 && dx != 0 && dx != 1) {console.log("Invalid dx"); return false;}
	if (pc.col+dx < 0 || pc.col+dx > 7) {console.log("Invalid destination"); return false;}

	var dy;
	if 	(pc.player == 1) dy = -1;
	else if (pc.player == 2) dy =  1;
	else return false;

	var dest = board.grid[pc.row+dy][pc.col+dx];
	if (dest.player == pc.player || (dest.player != 0 && dx == 0)) {console.log("Invalid capture"); return false;}

	board.grid[pc.row][pc.col] = new Piece(pc.row, pc.col, 0);
	pc.col = pc.col + dx;
	pc.row = pc.row + dy;
	board.grid[pc.row][pc.col] = pc;

	if (dest.player != 0)
		for (var p = 1; p <= 2; p++)
			for (var i = 0; i < board.pieces[3-p].length; i++)
				if (board.pieces[3-p][i] == dest)
					board.pieces[3-p].splice(i,1);

	return true;
}

//===================================================================
// Check win

BT_Game.prototype.checkWin = function(board) {
	if (board.pieces[1].length == 0) return 2;
	if (board.pieces[2].length == 0) return 1;
	for (var p = 1; p <= 2; p++)
		for (var i = 0; i < board.pieces[p].length; i++)
			if (board.pieces[p][i].row == (p == 1 ? 0 : 7))
				return p;
	return 0;
}

