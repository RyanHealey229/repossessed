#include "bt_game.h"

//---------- public

bt_game::bt_game(std::string player1, std::string player2): p1(player1), p2(player2), expanded(0) {};

void bt_game::play()
{ start(); }

void bt_game::play_irl()
{ start_irl(); }

//---------- private

std::vector<bt_game::piece> bt_game::getValidMoves(const bt_game::piece grid[8][8], bt_game::piece start)
{
	if (start.captured) return std::vector<bt_game::piece>();
	if (start.player == 0) return std::vector<bt_game::piece>();
	std::vector<bt_game::piece> validMoves;

	bt_game::piece move;
	int dy;
	if 	(start.player == 1) dy = 1;
	else if (start.player == 2) dy = -1;
	for (int dx = -1; dx < 2; dx++)
	{
		move = bt_game::piece(start.x+dx, start.y+dy, start.player, false);
		if (!(move.x<0 || move.x>7 || move.y<0 || move.y>7) && (grid[move.x][move.y].player == 0)) validMoves.push_back(move);
	}

	return validMoves;
}
std::vector<std::vector<bt_game::piece>> bt_game::getAllValidMoves(const bt_game::bt_state state, int player)
{
	std::vector<piece> pieces;
	std::vector<std::vector<bt_game::piece>> allValidMoves;
	if (player == 0) return allValidMoves;
	else if (player == 1) pieces = state.p1_pieces;
	else if (player == 2) pieces = state.p2_pieces;

	std::vector<piece> validMoves;
	for (size_t i = 0; i < 16; i++)
	{
		validMoves = getValidMoves(state.grid, state.p1_pieces[i]);
		for (size_t j = 0; j < validMoves.size(); j++)
			allValidMoves[i].push_back(validMoves[j]);
	}
	return allValidMoves;
}

void bt_game::move(bt_game::bt_state & state, bt_game::piece p, int dx, int dy)
{
	state.grid[p.x][p.y] = bt_game::piece();
	state.grid[p.x+dx][p.y+dy] = bt_game::piece(p.x+dx, p.y+dy, p.player, false);
	state.score = score(state);
}

int bt_game::score(const bt_state state)
{
	return state.score;
}

void bt_game::start()
{
	bt_game::bt_state startGrid;
	bt_game::piece p;
	p.captured = false;
	for (int i = 0; i < 8; i++)
	{
		p.x = i;
		if 	(i == 0 || i == 1)	p.player = 2;
		else if (i == 6 || i == 7)	p.player = 1;
		else				p.player = 0;

		for (int j = 0; j < 8; j++)
		{
			p.y = j;	
			startGrid.grid[i][j] = p;
		}
	}
	play(startGrid);
}

void bt_game::play(bt_game::bt_state state)
{
	bool won = true;
	if (won) printGrid(state.grid);
}

void bt_game::printGrid(bt_game::piece grid[8][8])
{
	char pieceChar;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if 	(grid[i][j].player == 1)	pieceChar = 'X';
			else if (grid[i][j].player == 2)	pieceChar = '0';
			else 					pieceChar = '_';
			std::cout << ' ' << pieceChar;
		}
		std::cout << std::endl;
	}
}

void bt_game::clear()
{
	p1 = "";
	p2 = "";
	expanded = 0;
}






void bt_game::start_irl()
{
	bt_game::bt_state startGrid;
	bt_game::piece p;
	p.captured = false;
	for (int i = 0; i < 8; i++)
	{
		p.x = i;
		if 	(i == 0 || i == 1)	p.player = 2;
		else if (i == 6 || i == 7)	p.player = 1;
		else				p.player = 0;

		for (int j = 0; j < 8; j++)
		{
			p.y = j;	
			startGrid.grid[i][j] = p;
		}
	}
	play_irl(startGrid);
}

void bt_game::play_irl(bt_game::bt_state state)
{
	bool won = true;
	if (won) printGrid(state.grid);
}










