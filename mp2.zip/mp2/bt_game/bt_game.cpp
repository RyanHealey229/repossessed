#include "bt_game.h"

//---------- public

bt_game::bt_game(std::string player1, std::string player2): p1(player1), p2(player2), expanded(0) {};

void bt_game::play()
{ start(); }

void bt_game::play_irl()
{ start_irl(); }

//---------- private

std::vector<bt_game::piece> bt_game::getValidMoves(const bt_game::piece grid[8][8], bt_game::piece p)
{
	if (p.player == 0) return std::vector<bt_game::piece>();
	std::vector<bt_game::piece> validMoves;

	bt_game::piece move;
	int dy;
	if 	(p.player == 1) dy = 1;
	else if (p.player == 2) dy = -1;
	for (int dx = -1; dx < 2; dx++)
	{
		move = bt_game::piece(p.x+dx, p.y+dy, p.player);
		if (!(move.x<0 || move.x>7 || move.y<0 || move.y>7) && (grid[move.x][move.y].player != p.player)) validMoves.push_back(move);
	}

	return validMoves;
}
std::vector<std::vector<bt_game::piece>> bt_game::getAllValidMoves(const bt_game::bt_state state, int player)
{
	std::vector<piece> pieces;
	std::vector<std::vector<bt_game::piece>> allValidMoves;
	if (player == 0) return allValidMoves;
	else if (player == 1) pieces = state.p1_pieces;
	else if (player == 2) pieces = state.p2_pieces;

	std::vector<piece> validMoves;
	for (size_t i = 0; i < 16; i++)
		allValidMoves[i] = getValidMoves(state.grid, state.p1_pieces[i]);
	return allValidMoves;
}

bool bt_game::move(bt_game::bt_state & state, bt_game::piece p, int dx)
{
	int dy;
	auto place = std::find(state.p1_pieces.begin(), state.p1_pieces.end(), p);
	if 	(p.player == 1)
	{
		place = std::find(state.p1_pieces.begin(), state.p1_pieces.end(), p);
		if (place == state.p1_pieces.end()) return false;
		dy = -1;
	}
	else if (p.player == 2) 
	{
		place = std::find(state.p2_pieces.begin(), state.p2_pieces.end(), p);
		if (place == state.p2_pieces.end()) return false;
		dy = 1;
	}
	else return false;
	bt_game::piece dest = state.grid[p.y+dy][p.x+dx];
	if (dest.player == p.player || (dest.player != 0 && dx == 0)) return false;
	if (dx != -1 && dx != 0 && dx != 1) return false;
	if (p.x+dx < 0 || p.x+dx > 7) return false;

	if (p.player == 1) for (size_t i = 0; i < state.p1_pieces.size(); i++) if (state.p1_pieces[i] == p)
		state.p1_pieces[i] = piece(p.x+dx, p.y+dy, 1);
	if (p.player == 2) for (size_t i = 0; i < state.p2_pieces.size(); i++) if (state.p2_pieces[i] == p)
		state.p2_pieces[i] = piece(p.x+dx, p.y+dy, 2);

	
	if (dest.player != 0)
	{
		if (p.player == 1)
			for (size_t i = 0; i < state.p2_pieces.size(); i++)
				if (state.p2_pieces[i] == dest)
					state.p2_pieces.erase(state.p2_pieces.begin() + i);
		if (p.player == 2)
			for (size_t i = 0; i < state.p1_pieces.size(); i++)
				if (state.p1_pieces[i] == dest)
					state.p1_pieces.erase(state.p1_pieces.begin() + i);
	}

	state.grid[p.y][p.x] = bt_game::piece(p.x, p.y, 0);
	state.grid[p.y+dy][p.x+dx] = bt_game::piece(p.x+dx, p.y+dy, p.player);
	return true;
}

int bt_game::score(const bt_state state)
{
	return state.score;
}

int bt_game::checkWin(const bt_state state)
{
	if (state.p2_pieces.empty()) return 1;
	if (state.p1_pieces.empty()) return 2;
	for (size_t i = 0; i < state.p1_pieces.size(); i++)
		if (state.p1_pieces[i].y == 0) return 1;
	for (size_t i = 0; i < state.p2_pieces.size(); i++)
		if (state.p2_pieces[i].y == 7) return 2;
	return 0;
}

void bt_game::start()
{
	bt_game::bt_state startGrid;
	bt_game::piece p;
	for (int i = 0; i < 8; i++)
	{
		p.y = i;
		if 	(i == 0 || i == 1)	p.player = 2;
		else if (i == 6 || i == 7)	p.player = 1;
		else				p.player = 0;

		for (int j = 0; j < 8; j++)
		{
			p.x = j;	
			if 	(p.player == 2) startGrid.p2_pieces.push_back(p);
			else if (p.player == 1) startGrid.p1_pieces.push_back(p);
			startGrid.grid[i][j] = p;
		}
	}
	startGrid.score = 0;
	std::cout << "Player 1 pieces: " << startGrid.p1_pieces.size() << std::endl;
	std::cout << "Player 2 pieces: " << startGrid.p2_pieces.size() << std::endl;
	play(startGrid);
}

void bt_game::play(bt_game::bt_state state)
{
	bool won = true;
	if (won) printGrid(state.grid);
}

void bt_game::printGrid(bt_game::piece grid[8][8])
{
	std::cout << " | 0 1 2 3 4 5 6 7" << std::endl;
	std::cout << "-+----------------" << std::endl;
	for (int i = 0; i < 8; i++)
	{
		std::cout << i << "|";
		for (int j = 0; j < 8; j++)
		{
			if 	(grid[i][j].player == 1)	std::cout << " X";
			else if (grid[i][j].player == 2)	std::cout << " O";
			else 					std::cout << " _";
		}
		std::cout << std::endl;
	}
}

void bt_game::clear()
{
	p1 = "";
	p2 = "";
	expanded = 0;
}






void bt_game::start_irl()
{
	bt_game::bt_state startGrid;
	bt_game::piece p;
	for (int i = 0; i < 8; i++)
	{
		p.y = i;
		if 	(i == 0 || i == 1)	p.player = 2;
		else if (i == 6 || i == 7)	p.player = 1;
		else				p.player = 0;

		for (int j = 0; j < 8; j++)
		{
			p.x = j;	
			if 	(p.player == 2) startGrid.p2_pieces.push_back(p);
			else if (p.player == 1) startGrid.p1_pieces.push_back(p);
			startGrid.grid[i][j] = p;
		}
	}
	startGrid.score = 0;
	std::cout << "Player 1 pieces: " << startGrid.p1_pieces.size() << std::endl;
	std::cout << "Player 2 pieces: " << startGrid.p2_pieces.size() << std::endl;
	play_irl(startGrid);
}

void bt_game::play_irl(bt_game::bt_state state)
{
	int dx;
	piece p;
	bool valid;

	printGrid(state.grid);
	std::cout << std::endl;
	p.player = 1;
	valid = false;
	std::cout << "Player 1 move (x y dx): " << std::flush;
	while (!valid)
	{
		std::cin >> p.x >> p.y >> dx;
		std::cin.clear();
		std::cin.ignore();
		valid = move(state, p, dx);
		if (!valid) std::cout << "invalid move: try again" << std::endl;
	}
	std::cout << p.x << ',' << p.y << " => " << p.x+dx << ',' <<  p.y-1 << std::endl;
	if (checkWin(state) == 1) {std::cout << "Player 1 wins" << std::endl; return;}

	printGrid(state.grid);
	std::cout << std::endl;
	p.player = 2;
	valid = false;
	std::cout << "Player 2 move (x y dx): " << std::flush;
	while (!valid)
	{
		std::cin >> p.x >> p.y >> dx;
		std::cin.clear();
		std::cin.ignore();
		valid = move(state, p, dx);
		if (!valid) std::cout << "invalid move: try again" << std::endl;
	}
	std::cout << p.x << ',' << p.y << " => " << p.x+dx << ',' <<  p.y+1 << std::endl;
	if (checkWin(state) == 2) {std::cout << "Player 2 wins" << std::endl; return;}

	play_irl(state);
}










