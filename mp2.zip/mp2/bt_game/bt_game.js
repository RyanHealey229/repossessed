// BT_Game Implementation


function Piece(rr, cc, pp) {
	this.row = rr;
	this.col = cc;
	this.player = pp;
}

function Board(board) {
	var p;
	var piece;
	this.grid = [];
	this.pieces = [[],[],[]];
	if (!board) {
		this.score = 0;
		for (var row = 0; row < 8; row++) {
			this.grid.push([]);
			if (row < 2) p = 2;
			else if (row > 5) p = 1;
			else p = 0;
			for (var col = 0; col < 8; col++) {
				piece = new Piece(col,row,p)
				this.grid[row].push(piece);
				this.pieces[p].push(piece);
				console.log("Added a piece");
			}
		}
	} else {
		this.score = board.score;
		for (var row = 0; row < 8; row++) {
			this.grid.push([]);
			for (var col = 0; col < 8; col++) {
				p = board.grid[row][col].player;
				piece = new Piece(row, col, p);
				this.grid[row].push(piece);
				this.pieces[p].push(piece);
			}
		}
	}
}

function BT_Game(p1str, p2str) {
	this.p1 = p1str;
	this.p2 = p2str;
	this.expanded = 0;
}

BT_Game.prototype.getValidMoves = function(grid, pc) {
	return [];
}

BT_Game.prototype.getAllValidMoves = function(board, player) {
	return [];
}

BT_Game.prototype.move = function(board, pc, dx) {
	if (dx != -1 && dx != 0 && dx != 1) {console.log("Invalid dx"); return false;}
	if (pc.col+dx < 0 || pc.col+dx > 7) {console.log("Invalid destination"); return false;}

	var dy;
	if 	(pc.player == 1) dy = -1;
	else if (pc.player == 2) dy =  1;
	else return false;

	var dest = board.grid[pc.row+dy][pc.col+dx];
	if (dest.player == pc.player || (dest.player != 0 && dx == 0)) {console.log("Invalid capture"); return false;}
	board.grid[pc.row][pc.col] = new Piece(pc.row, pc.col, 0);
	pc.col = pc.col + dx;
	pc.row = pc.row + dy;
	board.grid[pc.row][pc.col] = pc;

	if (dest.player != 0)
		for (var p = 1; p <= 2; p++)
			for (var i = 0; i < board.pieces[3-p].length; i++)
				if (board.pieces[3-p][i] == dest)
					board.pieces[3-p].splice(i,1);

	return true;
}

BT_Game.prototype.score = function(board) {
	return 0;
}

BT_Game.prototype.checkWin = function(board) {
	if (board.pieces[1].length == 0) return 2;
	if (board.pieces[2].length == 0) return 1;
	for (var p = 1; p <= 2; p++)
		for (var i = 0; i < board.pieces[p].length; i++)
			if (board.pieces[p][i].row == (p == 1 ? 0 : 7))
				return p;
	return 0;
}

BT_Game.prototype.start = function() {
	this.play(new Board(null), this.p1, this.p2);
}

BT_Game.prototype.play = function(board) {
	var row = 8;
	var col = 8;
	var dx = 0;
	var pc = new Piece(0,0,1);
	var valid = false;
	var input = "";
	var invars = [];
	var board_copy = new Board(board);

	this.printGrid(board_copy.grid);
	while (!valid) {
		console.log("Player 1 move (row col dx): ");
		input = prompt("Player 1 move (row col dx): ");
		invars = input.split(' ');
		row = parseInt(invars[0]);
		col = parseInt(invars[1]);
		dx = parseInt(invars[2]);
		pc = board_copy.grid[row][col];
		console.log(pc.row, pc.col, dx);
		valid = (pc.player == 1 && this.move(board_copy, pc, dx));
		if (!valid) console.log("invalid move: try again");
	}
	if (this.checkWin(board_copy) == 1) {console.log("Player 1 wins"); return;}

	valid = false;
	this.printGrid(board_copy.grid);
	while (!valid) {
		console.log("Player 2 move (row col dx): ");
		input = prompt("Player 2 move (row col dx): ");
		invars = input.split(' ');
		row = parseInt(invars[0]);
		col = parseInt(invars[1]);
		dx = parseInt(invars[2]);
		pc = board_copy.grid[row][col];
		console.log(pc.row, pc.col, dx);
		valid = (pc.player == 2 && this.move(board_copy, pc, dx));
		if (!valid) console.log("invalid move: try again");
	}
	if (this.checkWin(board_copy) == 2) {console.log("Player 2 wins"); return;}

	this.play(board_copy);
}

BT_Game.prototype.printGrid = function(grid) {
	var logtext = "";
	logtext += "  | 0 1 2 3 4 5 6 7\n";
	logtext += "--+----------------\n";
	for (var i = 0; i < 8; i++) {
		logtext += i;
		logtext += "|";
		for (var j = 0; j < 8; j++) {
			if      (grid[i][j].player == 1) logtext += " X";
			else if (grid[i][j].player == 2) logtext += " O";
			else                             logtext += " _";
		}
		logtext += "\n";
	}
	console.log(logtext);
}



