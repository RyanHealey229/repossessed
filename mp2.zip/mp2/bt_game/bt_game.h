#ifndef BREAKTHROUGH_H
#define BREAKTHROUGH_H
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

class bt_game
{
public:
	bt_game(std::string player1, std::string player2);
	void play();
	void play_irl();

	struct piece
	{
		int x, y, player;
		piece(): x(0), y(0), player(0) {};
		piece(int px, int py, int pplayer): x(px), y(py), player(pplayer) {};
		bool operator==(piece rhs) {return (x==rhs.x && y==rhs.y && player==rhs.player);};
	};
	struct bt_state
	{
		piece grid[8][8];
		std::vector<piece> p1_pieces;
		std::vector<piece> p2_pieces;
		int score;
	};

private:
	std::string p1;
	std::string p2;
	size_t expanded;
	std::vector<piece> getValidMoves(const piece grid[8][8], piece p);
	std::vector<std::vector<piece>> getAllValidMoves(const bt_state state, int player);
	bool move(bt_state & state, piece p, int dx);
	int score(const bt_state state);
	int checkWin(const bt_state state);
	void start();
	void play(bt_state state);
	void printGrid(piece grid[8][8]);
	void clear();

	void start_irl();
	void play_irl(bt_state state);
};

#endif
