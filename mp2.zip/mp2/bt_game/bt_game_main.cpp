#include "bt_game.h"

int main()
{
	bt_game game = bt_game("minimax", "alphabeta");
	game.play_irl();
	return 0;
};
