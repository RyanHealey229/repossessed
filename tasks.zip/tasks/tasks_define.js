
function TaskList() {
	this.size = 0;
	this.root = null;
}

function TaskNode(task) {
	this.task = task;
	this.subs = new TaskList();
	this.next = null;
	this.prev = null;
}

TaskList.prototype.getEnd = function() {
	var node = this.root;
	if (!node) return null;
	while (node.next) node = node.next;
	return node;
}

TaskList.prototype.find = function(node, task) {
	if (!node) return null;
	if (node.task == task) return node;
	var nextnode = null;
	if (node.next) nextnode = this.find(node.next, task);
	if (!nextnode && node.subs && node.subs.root) nextnode = this.find(task, node.subs.root);
	return nextnode;
}

TaskList.prototype.add = function(prevnode, node) {
	if (!this.root) {
		this.root = node;
	} else if (!prevnode) {
		node.next = this.root;
		node.next.prev = node;
		this.root = node;
	} else {
		node.next = prevnode.next;
		node.prev = prevnode;
		if (node.next) node.next.prev = node;
		prevnode.next = node;
	}
	this.size++;
}

TaskList.prototype.remove = function(node) {
	if (!node) return;
	if (node.subs && node.subs.root) {
		var curr = node.subs.root;
		while (curr) {
			node.subs.remove(curr);
			curr = node.subs.root;
		}
	}
	if (this.root == node) this.root = node.next;
	if (node.next) node.next.prev = node.prev;
	if (node.prev) node.prev.next = node.next;
	node.subs = null;
	node.next = null;
	node.prev = null;
	this.size--;
}

TaskList.prototype.shift = function(node, dir) {
	var copynode = new TaskNode();
	copynode.task = node.task;
	copynode.subs = node.subs;
	if (dir == 'u' && node.prev) {
		this.add(node.prev.prev, copynode);
	} else if (dir == 'd' && node.next) {
		this.add(node.next, copynode);
	} else {
		this.add(node.prev, copynode);
	}
	this.remove(node);
}

TaskNode.prototype.toHTML = function() {
	var htmlText = "";
	htmlText += "<li class='sub' id='";
	htmlText += this.task.replace(/\ /g,"_");
	htmlText += "'><a class='move_u'>&uarr;</a>";
	htmlText += "<a class='move_d'>&darr;</a>";
	htmlText += "<a class='subtitle'>";
	htmlText += this.task;
	htmlText += "</a><a class='checkbox'></a></li>";
	return htmlText;
}

TaskList.prototype.toHTML = function(title) {
	var htmlText = "";
	htmlText += "<div id='header'><a id='back'>&larr;</a><h1>";
	htmlText += title;
	htmlText += "</h1></div><ul id='subs' class='sortable'>";
	var curr = this.root;
	while (curr) {
		htmlText += curr.toHTML();
		curr = curr.next;
	}
	htmlText += "</ul><div id='add_sub'><a class='subtitle_add'>";
	htmlText += "<input type='text' id='add_title'><a id='submit'>+</a></a></div>";
	return htmlText;
}

TaskList.prototype.read = function(text) {
}
