/*
	Implementation of Task List with tasks.html
	Currently adds and removes tasks
	Goals:
		Read from file for stored tasks
			Maybe use node.js for file writing?
		Animations
*/
var list = new TaskList();
var mainList = list;
var lists = [];
var node;
var nodef;

node = new TaskNode();
node.task = "task 1";
list.add(null, node); console.log("Added ", list.find(list.root, "task 1"));
node = new TaskNode();
node.task = "task 2";
list.add(list.root, node); console.log("Added ", list.find(list.root, "task 2"));
nodef = list.find(list.root, "task 2");
node = new TaskNode();
node.task = "task 3";
list.add(nodef, node); console.log("Added ", list.find(list.root, "task 3"));

lists.push(list);
list = new TaskList();
node = new TaskNode();
node.task = "task 2 part 1";
list.add(null, node);
node = new TaskNode();
node.task = "task 2 part 2";
list.add(list.root, node);

var topList = lists[lists.length-1];
node = topList.find(topList.root, "task 2");
node.subs = list;
list = lists.pop();
console.log(lists, list.find(list.root, "task 2").subs);

$(document).ready(function() {
	$('#task_box').html(list.toHTML("Tasks"));
	console.log('Added ',list,' to html');

	$('#task_box').on("click", ".checkbox", function() {
		var id = $(this).parent().attr('id');
		node = list.find(list.root, id.replace(/_/g," "));
		list.remove(node); console.log('Removed ',node);
		$('#task_box').html(list.toHTML("Tasks"));
	});

	$('#task_box').on("click", "#submit", function() {
		node = new TaskNode();
		node.task = $('input').val();
		nodef = list.getEnd(); console.log(node);
		list.add(nodef, node); console.log("Added ", list.find(list.root, node.task));
		$('#task_box').html(list.toHTML("Tasks"));
	});
	
	$('#task_box').on("click", ".move_u", function() {
		var id = $(this).parent().attr('id');
		node = list.find(list.root, id.replace(/_/g," "));
		list.shift(node, 'u');
		$('#task_box').html(list.toHTML("Tasks"));
	});
	$('#task_box').on("click", ".move_d", function() {
		var id = $(this).parent().attr('id');
		node = list.find(list.root, id.replace(/_/g," "));
		list.shift(node, 'd');
		$('#task_box').html(list.toHTML("Tasks"));
	});
	
	$('#task_box').on("click", ".subtitle", function() {
		console.log("select");
		var id = $(this).parent().attr('id');
		node = list.find(list.root, id.replace(/_/g," "));
		lists.push(list);
		list = node.subs;
		$('#task_box').html(list.toHTML("Tasks"));
	});

	$('#task_box').on("click", "#back", function() {
		console.log("back");
		if (lists.length > 0) list = lists.pop();
		$('#task_box').html(list.toHTML("Tasks"));
	});

});

        /*
                Tasks
                {
                task 1
                task 2
                {
                task 2 1
                task 2 2
                task 2 3
                }
                task 3
                {
                task 3 1
                task 3 2
                {
                task 3 2 1
                task 3 2 2
                task 3 2 3
                }
                }
                task 4
                task 5
                }
        */

